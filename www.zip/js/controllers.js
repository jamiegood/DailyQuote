angular.module('starter.controllers', [])

.controller('HomeCtrl', function($scope, $ionicActionSheet, Quotes) {

  //create actionSheet for share options.
  $scope.showShare = function(quote, event) {
     // Show the action sheet
     var hideSheet = $ionicActionSheet.show({
       buttons: [
         { text: 'Facebook' },
         { text: 'Twitter' },
         { text: 'LinkedIn' },
         { text: 'Email' }
       ],
       titleText: 'Share this quote',
       cancelText: 'Cancel',
       cancel: function() {
            // add cancel code..
          },
       buttonClicked: function(index) {
         return true;
       }
     });
   };  

   $scope.save = function(quote) {
    console.log('save quote');


   }
})

.controller('FavouritesCtrl', function($scope, Quotes) {
  // With the new view caching in Ionic, Controllers are only called
  // when they are recreated or on app start, instead of every page change.
  // To listen for when this page is active (for example, to refresh data),
  // listen for the $ionicView.enter event:
  //
  //$scope.$on('$ionicView.enter', function(e) {
  //});
  
  $scope.quotes = Quotes.all();

  $scope.remove = function(quote) {
    Quotes.remove(quote);
  }


})

.controller('FavouritesDetailCtrl', function($scope, $stateParams, Quotes) {
  $scope.chat = Quotes.get($stateParams.chatId);
})

.controller('SettingsCtrl', function($scope) {
  $scope.settings = {
    enableFriends: true
  };
});
